package sample;

public class SampleCalls {
    private final Sample s = new Sample("abc");

    public void run() {
        s.inc();              
        int n = s.size();        
        String upper = s.name.toUpperCase(); 
        System.out.println(n);   
    }
}
