package sample;

interface Namer { String get(); }

class Base {}

public class Sample extends Base implements Namer {
    private int count;
    public String name;

    public Sample(String name) { this.name = name; }

    protected void inc() { count++; }
    void reset() { count = 0; }
    public int size() { return name == null ? 0 : name.length(); }

    @Override
    public String get() { return name; }
}
