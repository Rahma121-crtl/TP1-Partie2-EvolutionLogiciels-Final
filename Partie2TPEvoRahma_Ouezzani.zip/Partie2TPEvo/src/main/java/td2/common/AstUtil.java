package td2.common;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * TP1 - Partie 2
 * Utilitaires communs autour de JDT :
 *  - gestion du dossier des sources (SOURCE_ROOT)
 *  - parsing de fichiers Java en AST (CompilationUnit) avec résolution des types
 *  - fonctions d'aide pour compter des lignes de code (LOC) en retirant les commentaires
 *
 * Remarque : cette classe ne contient aucune logique métier du TP ; elle factorise
 * ce qui est commun à Ex1 (métriques) et Ex2 (graphe d'appel).
 */
public final class AstUtil {

    // Racine des sources à analyser 
    public static Path SOURCE_ROOT = Paths.get("src/main/java/company");

    private AstUtil() {} // utilitaire non instanciable

    /**
     * Parcourt récursivement la racine et liste tous les fichiers .java.
     */
    public static List<Path> listJavaFiles(Path root) {
        try (Stream<Path> s = Files.walk(root)) {
            return s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Parse un fichier Java en AST (CompilationUnit) avec JDT en activant
     * la résolution de types (bindings).
     * @param classSource contenu du fichier (char[])
     * @param file chemin du fichier (sert au nom d'unité et à l'environnement)
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static CompilationUnit parse(char[] classSource, Path file) {
        try {
            // Parser JDT configuré pour créer une CompilationUnit avec bindings
            ASTParser parser = ASTParser.newParser(AST.JLS17);
            parser.setResolveBindings(true);
            parser.setKind(ASTParser.K_COMPILATION_UNIT);
            parser.setBindingsRecovery(true);

            // On force la conformité Java 17
            Map options = JavaCore.getOptions();
            JavaCore.setComplianceOptions(JavaCore.VERSION_17, options);
            parser.setCompilerOptions(options);

            // Contexte d'analyse : unit name, sources et classpath
            parser.setUnitName(file.getFileName().toString());
            String[] sources = { SOURCE_ROOT.toAbsolutePath().toString() };
            String[] classpath = { Paths.get("target/classes").toAbsolutePath().toString() };
            parser.setEnvironment(classpath, sources, new String[] { "UTF-8" }, true);

            parser.setSource(classSource);
            return (CompilationUnit) parser.createAST(null);
        } catch (Exception e) {
            // Message explicite si un fichier me pose problème
            throw new RuntimeException("Parse failed for " + file, e);
        }
    }

    // Regex pour repérer les commentaires ligne et bloc
    private static final Pattern LINE_COMMENT  = Pattern.compile("//.*?$", Pattern.MULTILINE);
    private static final Pattern BLOCK_COMMENT = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);

    /**
     * Supprime les commentaires // et /* ... */ 
    public static String stripComments(String source) {
        String no = LINE_COMMENT.matcher(source).replaceAll("");
        return BLOCK_COMMENT.matcher(no).replaceAll("");
    }

    /**
     * Compte les lignes non vides hors commentaires (LOC "global").
     */
    public static long countLOCNoComments(String source) {
        String no = stripComments(source);
        return no.lines().map(String::trim).filter(l -> !l.isEmpty()).count();
    }

    /**
     * Compte les lignes non vides dans un corps de méthode,
     * en retirant les accolades seules { } et les commentaires.
     */
    public static long countLOCBody(String bodySource) {
        String no = stripComments(bodySource);
        return no.lines()
                 .map(String::trim)
                 .filter(l -> !l.isEmpty())
                 .filter(l -> !l.equals("{") && !l.equals("}"))
                 .count();
    }
}
