package td2.ex1;

import org.eclipse.jdt.core.dom.*;
import td2.common.AstUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
// important : pas de java.awt.* pour éviter le conflit avec List
import java.awt.Font;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

public class Ex1Metrics {

   
    public static class MethodInfo {
        public final String classFqn, name;
        public final int paramCount;
        public final long bodyLOC; 
        public MethodInfo(String classFqn, String name, int paramCount, long bodyLOC) {
            this.classFqn = classFqn; this.name = name; this.paramCount = paramCount; this.bodyLOC = bodyLOC;
        }
    }

   
    public static class ClassInfo {
        public final String fqn;
        public int attrCount = 0;
        public final List<MethodInfo> methods = new ArrayList<>();
        public ClassInfo(String fqn) { this.fqn = fqn; }
        public int  methodCount()    { return methods.size(); }
        public long sumMethodLOC()   { return methods.stream().mapToLong(m -> Math.max(m.bodyLOC, 0)).sum(); }
        public long methodsWithBody(){ return methods.stream().filter(m -> m.bodyLOC >= 0).count(); }
    }

    public static void main(String[] args) throws Exception {
        // X = seuil pour la question (11). --gui active la fenêtre Swing.
        int X = 3;
        boolean showGui = false;
        for (String a : args) {
            if ("--gui".equalsIgnoreCase(a)) showGui = true;
            else { try { X = Integer.parseInt(a); } catch (NumberFormatException ignored) {} }
        }

        // Récupération de tous les fichiers Java à partir de SOURCE_ROOT
        List<Path> files = AstUtil.listJavaFiles(AstUtil.SOURCE_ROOT);
        Map<String, ClassInfo> classes = new LinkedHashMap<>();
        Set<String> packages = new HashSet<>();
        long totalLOCGlobal = 0;

        // Analyse fichier par fichier : on parse en AST et on visite
        for (Path file : files) {
            String content = Files.readString(file);
            CompilationUnit cu = AstUtil.parse(content.toCharArray(), file);

            // Collecte des packages distincts
            if (cu.getPackage() != null) {
                packages.add(cu.getPackage().getName().getFullyQualifiedName());
            }

            // Visiteur des classes / champs / méthodes
            cu.accept(new ASTVisitor() {
                @Override public boolean visit(TypeDeclaration node) {
                    if (node.isInterface()) return true; // on ignore les interfaces pour les métriques de classes

                    // FQN = package + nom de classe (ou <default> sans package)
                    String pkg = (cu.getPackage() == null) ? "<default>"
                            : cu.getPackage().getName().getFullyQualifiedName();
                    String fqn = pkg.equals("<default>") ? node.getName().getIdentifier()
                            : pkg + "." + node.getName().getIdentifier();

                    ClassInfo ci = classes.computeIfAbsent(fqn, ClassInfo::new);

                    // Compte des attributs = nombre de fragments déclarés
                    for (FieldDeclaration fd : node.getFields()) {
                        @SuppressWarnings("unchecked")
                        List<VariableDeclarationFragment> frags = fd.fragments();
                        ci.attrCount += frags.size();
                    }

                    // Collecte des méthodes (nom, #params, LOC du corps)
                    for (MethodDeclaration md : node.getMethods()) {
                        int params = md.parameters().size();
                        long locBody = -1;
                        if (md.getBody() != null) {
                            // On récupère uniquement le bloc de la méthode pour compter le LOC du corps
                            int start = md.getBody().getStartPosition();
                            int length = md.getBody().getLength();
                            String body = content.substring(start, start + length);
                            locBody = AstUtil.countLOCBody(body);
                        }
                        ci.methods.add(new MethodInfo(fqn, md.getName().getIdentifier(), params, locBody));
                    }
                    return true;
                }
            });

            // LOC global du fichier (lignes non vides hors commentaires)
            totalLOCGlobal += AstUtil.countLOCNoComments(content);
        }

        // Agrégations globales
        int nbClasses = classes.size();
        int nbMethods = classes.values().stream().mapToInt(ClassInfo::methodCount).sum();
        int nbAttrs   = classes.values().stream().mapToInt(c -> c.attrCount).sum();
        long sumMethodLOC = classes.values().stream().mapToLong(ClassInfo::sumMethodLOC).sum();
        long nbMethodsWithBody = classes.values().stream().mapToLong(ClassInfo::methodsWithBody).sum();

        // Affichages demandés 1→4
        System.out.println("=== Q1.1 (1→4) ===");
        System.out.println("1) Nombre de classes                 : " + nbClasses);
        System.out.println("2) Nombre de lignes de code (global) : " + totalLOCGlobal + " (non vides, sans commentaires)");
        System.out.println("3) Nombre total de méthodes          : " + nbMethods);
        System.out.println("4) Nombre total de packages          : " + packages.size() + "  " + packages);

        // 5→7 : moyennes (avec protections /0)
        double avgMethPerClass = nbClasses == 0 ? 0.0 : (double) nbMethods / nbClasses;
        double avgAttrPerClass = nbClasses == 0 ? 0.0 : (double) nbAttrs / nbClasses;
        double avgLOCPerMethod = nbMethodsWithBody == 0 ? 0.0 : (double) sumMethodLOC / nbMethodsWithBody;
        System.out.println("\n=== Q1.1 (5→7) ===");
        System.out.printf("5) Moyenne méthodes / classe         : %.2f%n", avgMethPerClass);
        System.out.printf("6) Moyenne lignes / méthode (corps)  : %.2f%n", avgLOCPerMethod);
        System.out.printf("7) Moyenne attributs / classe        : %.2f%n", avgAttrPerClass);

        // 8→10 : top 10% par nb de méthodes / attributs + intersection
        System.out.println("\n=== Q1.1 (8→10) ===");
        int k = Math.max(1, (int) Math.ceil(0.10 * nbClasses));
        List<ClassInfo> topByMethods = classes.values().stream()
                .sorted(Comparator.comparingInt(ClassInfo::methodCount).reversed())
                .limit(k).collect(Collectors.toList());
        List<ClassInfo> topByAttrs = classes.values().stream()
                .sorted(Comparator.comparingInt((ClassInfo c) -> c.attrCount).reversed())
                .limit(k).collect(Collectors.toList());
        System.out.println("8) Top 10% classes par nb de méthodes (k=" + k + "):");
        topByMethods.forEach(c -> System.out.println("   - " + c.fqn + " : " + c.methodCount() + " méthodes"));
        System.out.println("9) Top 10% classes par nb d'attributs (k=" + k + "):");
        topByAttrs.forEach(c -> System.out.println("   - " + c.fqn + " : " + c.attrCount + " attributs"));
        Set<String> inter = topByMethods.stream().map(ci -> ci.fqn).collect(Collectors.toSet());
        inter.retainAll(topByAttrs.stream().map(ci -> ci.fqn).collect(Collectors.toSet()));
        System.out.println("10) Intersection                      : " + (inter.isEmpty() ? "∅" : inter));

        // 11→13 : > X méthodes, top 10% méthodes les plus longues (par classe + global), max #params
        System.out.println("\n=== Q1.1 (11→13) ===");
        int seuil = X;
        List<ClassInfo> overX = classes.values().stream()
                .filter(c -> c.methodCount() > seuil)
                .sorted(Comparator.comparingInt(ClassInfo::methodCount).reversed())
                .collect(Collectors.toList());
        System.out.println("11) Classes avec > " + seuil + " méthodes : " +
                (overX.isEmpty() ? "aucune"
                        : overX.stream().map(c -> c.fqn + " (" + c.methodCount() + ")").collect(Collectors.joining(", "))));

        System.out.println("12) Top 10% méthodes les plus longues (par classe) :");
        List<String> topPerClassLines = new ArrayList<>();
        Map<String, List<MethodInfo>> topPerClass = new LinkedHashMap<>();
        for (ClassInfo ci : classes.values()) {
            List<MethodInfo> withBody = ci.methods.stream().filter(m -> m.bodyLOC >= 0).collect(Collectors.toList());
            int kMeth = Math.max(1, (int) Math.ceil(0.10 * withBody.size()));
            withBody.sort(Comparator.comparingLong((MethodInfo m) -> m.bodyLOC).reversed());
            List<MethodInfo> top = withBody.stream().limit(kMeth).collect(Collectors.toList());
            topPerClass.put(ci.fqn, top);
            System.out.println("   - " + ci.fqn + " (k=" + kMeth + "):");
            if (top.isEmpty()) System.out.println("       (aucune méthode avec corps)");
            for (MethodInfo m : top) {
                System.out.println("       • " + m.name + " : " + m.bodyLOC + " LOC");
                topPerClassLines.add(ci.fqn + "," + m.name + "," + m.bodyLOC);
            }
        }

        // Top global (10% des méthodes avec corps)
        List<MethodInfo> methodsWithBody = classes.values().stream()
                .flatMap(c -> c.methods.stream()).filter(m -> m.bodyLOC >= 0).collect(Collectors.toList());
        int kMethGlobal = Math.max(1, (int) Math.ceil(0.10 * methodsWithBody.size()));
        List<MethodInfo> topLongGlobal = methodsWithBody.stream()
                .sorted(Comparator.comparingLong((MethodInfo m) -> m.bodyLOC).reversed())
                .limit(kMethGlobal).collect(Collectors.toList());
        System.out.println("   (global) k=" + kMethGlobal + " :");
        for (MethodInfo m : topLongGlobal) {
            System.out.println("       • " + m.classFqn + "." + m.name + " : " + m.bodyLOC + " LOC");
        }

        // Max paramètres sur toutes les méthodes
        int maxParams = classes.values().stream()
                .flatMap(c -> c.methods.stream()).mapToInt(m -> m.paramCount).max().orElse(0);
        List<MethodInfo> maxParamMethods = classes.values().stream()
                .flatMap(c -> c.methods.stream()).filter(m -> m.paramCount == maxParams).collect(Collectors.toList());
        System.out.println("13) Nombre maximal de paramètres      : " + maxParams);
        if (!maxParamMethods.isEmpty()) {
            System.out.println("    Méthodes concernées :");
            maxParamMethods.forEach(m -> System.out.println("      - " + m.classFqn + "." + m.name));
        }

        // Exports CSV (répertoire target/reports)
        Path outDir = Path.of("target", "reports");
        Files.createDirectories(outDir);

        // Tableau par classe (métriques agrégées)
        Path classesCsv = outDir.resolve("metrics-classes.csv");
        List<String> lines = new ArrayList<>();
        lines.add("class,methods,attributes,methodsWithBody,sumMethodLOC,avgMethodLOC");
        for (ClassInfo ci : classes.values()) {
            double avg = ci.methodsWithBody() == 0 ? 0.0 : ((double) ci.sumMethodLOC()) / ci.methodsWithBody();
            lines.add(ci.fqn + "," + ci.methodCount() + "," + ci.attrCount + "," +
                    ci.methodsWithBody() + "," + ci.sumMethodLOC() + "," +
                    String.format(java.util.Locale.ROOT,"%.2f",avg));
        }
        Files.write(classesCsv, lines);

        // Top longues méthodes par classe
        Path topPerClassCsv = outDir.resolve("metrics-top-long-per-class.csv");
        List<String> lines2 = new ArrayList<>();
        lines2.add("class,method,loc");
        lines2.addAll(topPerClassLines);
        Files.write(topPerClassCsv, lines2);

        // Top global des longues méthodes
        Path topGlobalCsv = outDir.resolve("metrics-top-long-global.csv");
        List<String> lines3 = new ArrayList<>();
        lines3.add("class,method,loc");
        for (MethodInfo m : topLongGlobal) lines3.add(m.classFqn + "," + m.name + "," + m.bodyLOC);
        Files.write(topGlobalCsv, lines3);

        // Rappel des fichiers analysés (utile pour le correcteur)
        System.out.println("\nFichiers analysés :");
        files.forEach(p -> System.out.println(" - " + AstUtil.SOURCE_ROOT.relativize(p)));
        System.out.println("\n[CSV] Écrits dans " + outDir.toAbsolutePath());

        // GUI optionnelle (onglets Résumé / Classes / Tops / Fichiers)
        if (showGui) {
            final long totalLOCGlobalF = totalLOCGlobal;
            SwingUtilities.invokeLater(() ->
                    showMetricsGUI(nbClasses, totalLOCGlobalF, nbMethods, packages,
                                   avgMethPerClass, avgLOCPerMethod, avgAttrPerClass,
                                   topByMethods, topByAttrs, inter,
                                   seuil, overX, topPerClass, topLongGlobal,
                                   classes, files));
        }
    }

    /**
     * Affichage Swing simple des résultats (sans interaction avancée).
     * L'objectif est de donner un aperçu lisible au correcteur.
     */
    private static void showMetricsGUI(
            int nbClasses, long totalLOCGlobal, int nbMethods, Set<String> packages,
            double avgMethPerClass, double avgLOCPerMethod, double avgAttrPerClass,
            List<ClassInfo> topByMethods, List<ClassInfo> topByAttrs, Set<String> inter,
            int seuil, List<ClassInfo> overX, Map<String, List<MethodInfo>> topPerClass,
            List<MethodInfo> topLongGlobal,
            Map<String, ClassInfo> classes, List<Path> files) {

        JFrame f = new JFrame("TD2 — Exercice 1 (métriques)");
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        JTabbedPane tabs = new JTabbedPane();

        // Onglet "Résumé" (texte brut monospace)
        JTextArea resume = new JTextArea();
        resume.setEditable(false);
        resume.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        resume.setText(String.format(
            """
            === Q1.1 (1→4) ===
            1) #classes                      : %d
            2) #LOC (global, sans comm.)     : %d
            3) #méthodes total               : %d
            4) #packages                     : %d %s

            === Q1.1 (5→7) ===
            5) Moy. méthodes / classe        : %.2f
            6) Moy. lignes / méthode (corps) : %.2f
            7) Moy. attributs / classe       : %.2f

            === Q1.1 (8→10) ===
            8) Top méthodes                  : %s
            9) Top attributs                 : %s
            10) Intersection                 : %s

            === Q1.1 (11) ===
            Seuil X = %d → >X méthodes       : %s
            """,
            nbClasses, totalLOCGlobal, nbMethods,
            packages.size(), packages,
            avgMethPerClass, avgLOCPerMethod, avgAttrPerClass,
            topByMethods.stream().map(c -> c.fqn + "(" + c.methodCount() + ")").collect(Collectors.toList()),
            topByAttrs.stream().map(c -> c.fqn + "(" + c.attrCount + ")").collect(Collectors.toList()),
            inter, seuil,
            overX.isEmpty() ? "aucune" :
                    overX.stream().map(c -> c.fqn + "(" + c.methodCount() + ")").collect(Collectors.joining(", "))
        ));
        tabs.add("Résumé", new JScrollPane(resume));

        // Onglet "Classes" (tableau de métriques par classe)
        String[] cols = {"Classe", "#méthodes", "#attributs", "#méthodes (avec corps)", "Σ LOC méthodes", "Moy LOC/m."};
        DefaultTableModel model = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c){return false;} };
        classes.values().forEach(ci -> {
            double avg = ci.methodsWithBody()==0 ? 0.0 : ((double) ci.sumMethodLOC())/ci.methodsWithBody();
            model.addRow(new Object[]{ci.fqn, ci.methodCount(), ci.attrCount, ci.methodsWithBody(), ci.sumMethodLOC(),
                    String.format(java.util.Locale.ROOT,"%.2f", avg)});
        });
        JTable table = new JTable(model);
        tabs.add("Classes", new JScrollPane(table));

        // Onglet "Top par classe"
        JTextArea topClassArea = new JTextArea();
        topClassArea.setEditable(false);
        StringBuilder sb = new StringBuilder();
        topPerClass.forEach((fqn, list) -> {
            sb.append("• ").append(fqn).append(" :\n");
            if (list.isEmpty()) sb.append("   (aucune)\n");
            list.forEach(m -> sb.append("   - ").append(m.name).append(" : ").append(m.bodyLOC).append(" LOC\n"));
        });
        topClassArea.setText(sb.toString());
        tabs.add("Top par classe", new JScrollPane(topClassArea));

        // Onglet "Top global"
        StringBuilder sbg = new StringBuilder();
        topLongGlobal.forEach(m -> sbg.append(" - ").append(m.classFqn).append(".").append(m.name)
                .append(" : ").append(m.bodyLOC).append(" LOC\n"));
        JTextArea topGlobArea = new JTextArea(sbg.toString());
        topGlobArea.setEditable(false);
        tabs.add("Top global", new JScrollPane(topGlobArea));

        // Onglet "Fichiers"
        JTextArea filesArea = new JTextArea();
        files.forEach(p -> filesArea.append(" - " + AstUtil.SOURCE_ROOT.relativize(p) + "\n"));
        filesArea.setEditable(false);
        tabs.add("Fichiers", new JScrollPane(filesArea));

        f.setContentPane(tabs);
        f.setSize(new java.awt.Dimension(820, 600)); 
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}
