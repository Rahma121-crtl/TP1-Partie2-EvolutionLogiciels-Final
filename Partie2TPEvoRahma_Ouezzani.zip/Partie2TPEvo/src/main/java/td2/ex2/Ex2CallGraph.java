package td2.ex2;

import td2.common.AstUtil;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SuperMethodInvocation;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;

/**
 * TP1 - Partie 2 - Exercice 2 (Graphe d'appel statique)
 *
 * Objectif : construire un graphe d'appel (caller → callee) à partir de l'AST JDT :
 *  - chaque nœud est une méthode (ClasseFQN.méthode ou <init> pour constructeurs)
 *  - on capture les appels : MethodInvocation, SuperMethodInvocation, new T(...) -> T.<init>
 * Sorties :
 *  - affichage console (adjacence + arêtes)
 *  - DOT (GraphViz) et CSV des arêtes dans target/reports
 *  - Génération automatique du PNG avec GraphViz
 *  - GUI bonus simple pour visualiser le graphe (cercle)
 *
 * Utilisation (ex.) :
 *   java td2.ex2.Ex2CallGraph --src=src/main/java/sample
 */
public class Ex2CallGraph {

    public static void main(String[] args) throws Exception {
        boolean showGui = false;

        // Lecture des arguments : --src=... pour changer la racine, --gui pour afficher la GUI
        for (String a : args) {
            if (a.startsWith("--src=")) {
                td2.common.AstUtil.SOURCE_ROOT = Paths.get(a.substring("--src=".length()));
            } else if ("--gui".equalsIgnoreCase(a)) {
                showGui = true;
            }
        }

        // 1) Lister les fichiers et 2) construire une map caller -> {callees}
        List<Path> files = AstUtil.listJavaFiles(AstUtil.SOURCE_ROOT);
        Map<String, Set<String>> graph = new LinkedHashMap<>();

        // Analyse de chaque fichier
        for (Path file : files) {
            String content = Files.readString(file);
            CompilationUnit cu = AstUtil.parse(content.toCharArray(), file);

            String pkg = (cu.getPackage() == null) ? "<default>"
                    : cu.getPackage().getName().getFullyQualifiedName();

            cu.accept(new ASTVisitor() {
                @Override public boolean visit(TypeDeclaration type) {
                    if (type.isInterface()) return true;

                    String classFqn = pkg.equals("<default>") ? type.getName().getIdentifier()
                            : pkg + "." + type.getName().getIdentifier();

                    for (MethodDeclaration md : type.getMethods()) {
                        String caller = classFqn + "." + (md.isConstructor() ? "<init>" : md.getName().getIdentifier());
                        graph.computeIfAbsent(caller, k -> new LinkedHashSet<>());
                        if (md.getBody() == null) continue;

                        md.getBody().accept(new ASTVisitor() {
                            @Override public boolean visit(MethodInvocation inv) {
                                String calleeType = "<inconnu>";
                                IMethodBinding mb = inv.resolveMethodBinding();
                                if (mb != null && mb.getDeclaringClass() != null) {
                                    calleeType = mb.getDeclaringClass().getQualifiedName();
                                } else if (inv.getExpression() != null) {
                                    ITypeBinding tb = inv.getExpression().resolveTypeBinding();
                                    if (tb != null) calleeType = tb.getQualifiedName();
                                }
                                graph.get(caller).add(calleeType + "." + inv.getName().getIdentifier());
                                return true;
                            }

                            @Override public boolean visit(SuperMethodInvocation inv) {
                                String recv = "<inconnu>";
                                IMethodBinding mb = inv.resolveMethodBinding();
                                if (mb != null && mb.getDeclaringClass() != null) {
                                    recv = mb.getDeclaringClass().getQualifiedName();
                                }
                                graph.get(caller).add(recv + "." + inv.getName().getIdentifier());
                                return true;
                            }

                            @Override public boolean visit(ClassInstanceCreation cic) {
                                ITypeBinding tb = cic.resolveTypeBinding();
                                String typeQN = (tb != null) ? tb.getQualifiedName() : cic.getType().toString();
                                graph.get(caller).add(typeQN + ".<init>");
                                return true;
                            }
                        });
                    }
                    return true;
                }
            });
        }

        // Impression console
        System.out.println("=== Graphe d'appel (adjacence) ===");
        graph.forEach((caller, callees) -> {
            System.out.println(caller + " ->");
            if (callees.isEmpty()) System.out.println("   (aucun)");
            else callees.forEach(c -> System.out.println("   - " + c));
        });

        System.out.println("\n=== Arêtes (caller → callee) ===");
        graph.forEach((caller, callees) -> callees.forEach(callee -> System.out.println(caller + " → " + callee)));

        // Export DOT
        String dot = toDot(graph);
        Path outDir = Path.of("target", "reports");
        Files.createDirectories(outDir);

        Path dotFile = outDir.resolve("callgraph.dot");
        Files.writeString(dotFile, dot);
        System.out.println("\n[DOT] Écrit : " + dotFile.toAbsolutePath());

        // Génération automatique du PNG et ouverture immédiate
        try {
            String dotPath = dotFile.toAbsolutePath().toString();
            String pngPath = dotPath.replace(".dot", ".png");
            Process process = new ProcessBuilder("dot", "-Tpng", dotPath, "-o", pngPath).start();
            process.waitFor();
            System.out.println("[PNG] Généré : " + pngPath);

            // Ouvre automatiquement le PNG selon l’OS
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                new ProcessBuilder("cmd", "/c", "start", pngPath).start();
            } else if (os.contains("mac")) {
                new ProcessBuilder("open", pngPath).start();
            } else {
                new ProcessBuilder("xdg-open", pngPath).start();
            }

        } catch (Exception e) {
            System.err.println("⚠️ Erreur lors de la génération ou de l’ouverture du graphe : " + e.getMessage());
        }

        // Bonus CSV
        Path edgesCsv = outDir.resolve("callgraph-edges.csv");
        List<String> csv = new ArrayList<>();
        csv.add("caller,callee");
        graph.forEach((caller, callees) -> callees.forEach(callee -> csv.add(caller + "," + callee)));
        Files.write(edgesCsv, csv);
        System.out.println("[CSV] Écrit : " + edgesCsv.toAbsolutePath());

        // GUI optionnelle (--gui)
        if (showGui) showGraphGUI(graph);
    }

    /** Conversion du graphe en DOT (GraphViz) */
    private static String toDot(Map<String, Set<String>> graph) {
        StringBuilder sb = new StringBuilder("digraph G {\n");
        graph.forEach((caller, callees) -> {
            if (callees.isEmpty()) sb.append("  \"").append(caller).append("\";\n");
            else for (String callee : callees)
                sb.append("  \"").append(caller).append("\" -> \"").append(callee).append("\";\n");
        });
        sb.append("}\n");
        return sb.toString();
    }

    /** GUI bonus : affichage du graphe en cercle */
    private static void showGraphGUI(Map<String, Set<String>> graph) {
        Set<String> nodes = new LinkedHashSet<>(graph.keySet());
        graph.values().forEach(nodes::addAll);
        List<String> all = new ArrayList<>(nodes);
        int N = all.size();

        double R = 220, cx = 300, cy = 300;
        Map<String, Point> pos = new HashMap<>();
        for (int i = 0; i < N; i++) {
            double ang = 2 * Math.PI * i / Math.max(1, N);
            int x = (int) Math.round(cx + R * Math.cos(ang));
            int y = (int) Math.round(cy + R * Math.sin(ang));
            pos.put(all.get(i), new Point(x, y));
        }

        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g0) {
                super.paintComponent(g0);
                Graphics2D g = (Graphics2D) g0;
                g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,
                                   java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(Color.DARK_GRAY);
                graph.forEach((caller, callees) -> {
                    Point p1 = pos.get(caller);
                    for (String callee : callees) {
                        Point p2 = pos.get(callee);
                        if (p1 != null && p2 != null) g.drawLine(p1.x, p1.y, p2.x, p2.y);
                    }
                });
                int r = 18;
                for (String n : all) {
                    Point p = pos.get(n);
                    g.setColor(new Color(0x3f,0x7f,0xff));
                    g.fillOval(p.x - r, p.y - r, 2*r, 2*r);
                    g.setColor(Color.BLACK);
                    g.drawOval(p.x - r, p.y - r, 2*r, 2*r);
                    g.setFont(new Font("SansSerif", Font.PLAIN, 11));
                    g.drawString(shorten(n, 36), p.x - r, p.y - r - 4);
                }
            }
            private String shorten(String s, int max) {
                return (s.length() <= max) ? s : s.substring(0, max-1) + "…";
            }
        };
        panel.setPreferredSize(new java.awt.Dimension(640, 640));
        JFrame f = new JFrame("TD2 — Graphe d'appel");
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        f.setContentPane(panel);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}
