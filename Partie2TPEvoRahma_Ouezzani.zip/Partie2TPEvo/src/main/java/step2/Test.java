package step2;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

public class Test {
    public static void main(String[] args) {
        ASTParser parser = ASTParser.newParser(AST.JLS17); 
        String src = """
            import java.util.ArrayList;
            public class A {
              int i = 9;
              int j;
              ArrayList<Integer> al = new ArrayList<Integer>();
              { j = 1000; }
            }
            """;
        parser.setSource(src.toCharArray());
        parser.setKind(ASTParser.K_COMPILATION_UNIT);

        final CompilationUnit cu = (CompilationUnit) parser.createAST(null);

        cu.accept(new ASTVisitor() {
            Set<String> names = new HashSet<>();

            @Override
            public boolean visit(VariableDeclarationFragment node) {
                SimpleName name = node.getName();
                names.add(name.getIdentifier());
                System.out.println("Declaration of '" + name + "' at line " +
                        cu.getLineNumber(name.getStartPosition()));
                return false; 
            }

            @Override
            public boolean visit(SimpleName node) {
                if (names.contains(node.getIdentifier())) {
                    System.out.println("Usage of '" + node + "' at line " +
                            cu.getLineNumber(node.getStartPosition()));
                }
                return true;
            }
        });
    }
}
