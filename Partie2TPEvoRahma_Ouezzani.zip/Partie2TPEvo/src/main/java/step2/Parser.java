package step2;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.*;

public class Parser {

   
	public static final Path projectSourceRoot = Paths.get("src/main/java/sample");


    public static void main(String[] args) throws IOException {

        List<Path> javaFiles = listJavaFiles(projectSourceRoot);

        for (Path file : javaFiles) {
            String content = Files.readString(file);
            CompilationUnit cu = parse(content.toCharArray(), file);

            System.out.println("=== " + projectSourceRoot.relativize(file) + " ===");

          
            printMethodInfo(cu);

            
            printVariableInfo(cu);

           
            printMethodInvocationInfo(cu);

            System.out.println();
        }
    }

    
    public static List<Path> listJavaFiles(Path root) throws IOException {
        try (Stream<Path> s = Files.walk(root)) {
            return s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private static CompilationUnit parse(char[] classSource, Path file) {
        ASTParser parser = ASTParser.newParser(AST.JLS17); // Java 17
        parser.setResolveBindings(true);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        parser.setBindingsRecovery(true);

        Map options = JavaCore.getOptions();
        JavaCore.setComplianceOptions(JavaCore.VERSION_17, options);
        parser.setCompilerOptions(options);

        parser.setUnitName(file.getFileName().toString());

        String[] sources = { projectSourceRoot.toAbsolutePath().toString() };
        String[] classpath = { Paths.get("target/classes").toAbsolutePath().toString() };
        parser.setEnvironment(classpath, sources, new String[] { "UTF-8" }, true);

        parser.setSource(classSource);
        return (CompilationUnit) parser.createAST(null);
    }

    public static void printMethodInfo(CompilationUnit cu) {
        MethodDeclarationVisitor v = new MethodDeclarationVisitor();
        cu.accept(v);
        for (MethodDeclaration m : v.getMethods()) {
            System.out.println("Method name: " + m.getName()
                    + " Return type: " + m.getReturnType2());
        }
    }

    public static void printVariableInfo(CompilationUnit cu) {
        MethodDeclarationVisitor v1 = new MethodDeclarationVisitor();
        cu.accept(v1);
        for (MethodDeclaration m : v1.getMethods()) {
            VariableDeclarationFragmentVisitor v2 = new VariableDeclarationFragmentVisitor();
            m.accept(v2);
            for (VariableDeclarationFragment var : v2.getVariables()) {
                System.out.println("variable name: " + var.getName()
                        + " variable Initializer: " + var.getInitializer());
            }
        }
    }

    public static void printMethodInvocationInfo(CompilationUnit cu) {
        PackageDeclaration pkg = cu.getPackage();
        if (pkg != null && pkg.getName() != null) {
            String pname = pkg.getName().getFullyQualifiedName();
            if (!pname.startsWith("sample")) return;
        }

        MethodDeclarationVisitor v1 = new MethodDeclarationVisitor();
        cu.accept(v1);

        for (MethodDeclaration m : v1.getMethods()) {
            MethodInvocationVisitor v2 = new MethodInvocationVisitor();
            m.accept(v2);

            for (MethodInvocation inv : v2.getMethods()) {
                String called = inv.getName().getIdentifier();
                String recvType = "<inconnu>";

                IMethodBinding mb = inv.resolveMethodBinding();
                if (mb != null && mb.getDeclaringClass() != null) {
                    recvType = mb.getDeclaringClass().getQualifiedName();
                } else if (inv.getExpression() != null) {
                    ITypeBinding tb = inv.getExpression().resolveTypeBinding();
                    if (tb != null) recvType = tb.getQualifiedName();
                }

                System.out.println("method " + m.getName()
                        + " invoc " + called + "()  —  receiver: " + recvType);
            }

            for (SuperMethodInvocation sinv : v2.getSuperMethods()) {
                String recv = "<inconnu>";
                IMethodBinding mb = sinv.resolveMethodBinding();
                if (mb != null && mb.getDeclaringClass() != null) {
                    recv = mb.getDeclaringClass().getQualifiedName();
                }
                System.out.println("method " + m.getName()
                        + " super-invoc " + sinv.getName() + "()  —  receiver: " + recv);
            }
        }
    }

    }
