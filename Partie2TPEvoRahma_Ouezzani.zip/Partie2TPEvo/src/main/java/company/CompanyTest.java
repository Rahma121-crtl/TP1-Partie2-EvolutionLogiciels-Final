package company;

public class CompanyTest {
    public static void main(String[] args) {
        Employer boss = new Employer("TechCorp");
        Employee e1 = new Employee("Alice", 2500);
        Employee e2 = new Employee("Bob", 2300);

        boss.hire(e1);
        boss.hire(e2);

        boss.showAll();
        boss.makeEveryoneWork();

        e1.raiseSalary(200);
    }
}
