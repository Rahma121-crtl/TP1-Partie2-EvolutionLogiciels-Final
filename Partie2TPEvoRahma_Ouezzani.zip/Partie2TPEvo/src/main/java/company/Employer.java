package company;

import java.util.ArrayList;
import java.util.List;

public class Employer {
    private String companyName;
    private List<Employee> employees = new ArrayList<>();

    public Employer(String companyName) {
        this.companyName = companyName;
    }

    public void hire(Employee e) {
        employees.add(e);
        System.out.println(e.getName() + " has been hired by " + companyName);
    }

    public void showAll() {
        System.out.println("Employees of " + companyName + ":");
        for (Employee e : employees) {
            System.out.println(" - " + e.getName());
        }
    }

    public void makeEveryoneWork() {
        for (Employee e : employees) {
            e.work();
        }
    }
}
