package company;

public class Employee {

	private String name;
    private double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void work() {
        System.out.println(name + " is working...");
    }

    public void raiseSalary(double amount) {
        salary += amount;
        System.out.println(name + " got a raise. New salary: " + salary);
    }

    public String getName() {
        return name;
    }
}
